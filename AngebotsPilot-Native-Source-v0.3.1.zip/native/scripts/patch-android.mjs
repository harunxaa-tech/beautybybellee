import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const nativeDir = path.resolve(here, '..');
const manifestPath = path.join(nativeDir, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
const billingPermission = '<uses-permission android:name="com.android.vending.BILLING" />';

let manifest = await readFile(manifestPath, 'utf8');
if (!manifest.includes('android.permission.INTERNET')) {
  console.warn('AndroidManifest enthält keine erwartete INTERNET-Berechtigung; BILLING wird trotzdem ergänzt.');
}
if (!manifest.includes('com.android.vending.BILLING')) {
  manifest = manifest.replace(/(<manifest\b[^>]*>)/, `$1\n    ${billingPermission}`);
  await writeFile(manifestPath, manifest, 'utf8');
}
if (!manifest.includes('com.android.vending.BILLING')) throw new Error('Google Play BILLING permission konnte nicht gesetzt werden.');
console.log('Android project patched: Google Play BILLING permission present.');
