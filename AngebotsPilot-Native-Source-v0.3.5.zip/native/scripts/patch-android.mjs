import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const nativeDir = path.resolve(here, '..');
const manifestPath = path.join(nativeDir, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
const billingPermission = '<uses-permission android:name="com.android.vending.BILLING" />';
const microphonePermission = '<uses-permission android:name="android.permission.RECORD_AUDIO" />';

let manifest = await readFile(manifestPath, 'utf8');
if (!manifest.includes('android.permission.INTERNET')) {
  console.warn('AndroidManifest enthält keine erwartete INTERNET-Berechtigung; BILLING wird trotzdem ergänzt.');
}
if (!manifest.includes('com.android.vending.BILLING')) {
  manifest = manifest.replace(/(<manifest\b[^>]*>)/, `$1\n    ${billingPermission}`);
}
if (!manifest.includes('android.permission.RECORD_AUDIO')) {
  manifest = manifest.replace(/(<manifest\b[^>]*>)/, `$1\n    ${microphonePermission}`);
}
await writeFile(manifestPath, manifest, 'utf8');
if (!manifest.includes('com.android.vending.BILLING')) throw new Error('Google Play BILLING permission konnte nicht gesetzt werden.');
if (!manifest.includes('android.permission.RECORD_AUDIO')) throw new Error('Android RECORD_AUDIO permission konnte nicht gesetzt werden.');
console.log('Android project patched: Google Play BILLING + microphone permissions present.');
