/* AngebotsPilot Native v0.3.1 – Apple StoreKit / Google Play bridge
   Entitlements are NEVER granted from the device alone. Every purchase/restore
   must pass the authenticated Supabase store-billing-verify edge function first. */
(function(){
  'use strict';

  if(!globalThis.__ANGEBOTSPILOT_NATIVE__)return;

  const BUILD='0.3.1';
  const SUBS='subs';
  let listenerInstalled=false;

  const cap=()=>globalThis.Capacitor||null;
  const native=()=>cap()?.Plugins?.NativePurchases||null;
  const cloud=()=>{try{return globalThis.APCloudContext?.()||null}catch{return null}};
  const platform=()=>String(cap()?.getPlatform?.()||globalThis.__AP_NATIVE_PLATFORM__||'').toLowerCase();
  const provider=()=>platform()==='ios'?'apple':platform()==='android'?'google':'';

  function transactionEnvironment(transaction,fallback='production'){
    const raw=String(transaction?.environment||'').toLowerCase();
    if(raw.includes('sandbox'))return 'sandbox';
    if(raw.includes('production'))return 'production';
    return String(fallback||'production').toLowerCase()==='sandbox'?'sandbox':'production';
  }

  function textError(error,fallback){
    return String(error?.message||error?.error||error||fallback||'Unbekannter Fehler');
  }
  function isCancelled(error){
    const t=(String(error?.code||'')+' '+textError(error,'')).toLowerCase();
    return /cancel|canceled|cancelled|user.?cancel/.test(t);
  }
  function assertBridge(){
    const p=native();
    if(!p)throw new Error('Native Store-Billing ist in diesem Build nicht verfügbar.');
    return p;
  }
  async function ensureSupported(){
    const p=assertBridge();
    if(typeof p.isBillingSupported!=='function')throw new Error('Store-Billing wird von diesem Build nicht unterstützt.');
    const result=await p.isBillingSupported();
    if(!result?.isBillingSupported)throw new Error('Store-Billing ist auf diesem Gerät nicht verfügbar.');
    return p;
  }

  function matchProduct(entry,products){
    if(!entry||!Array.isArray(products))return null;
    if(provider()==='apple'){
      return products.find(x=>String(x?.identifier||x?.planIdentifier||'')===String(entry.product_id||''))||null;
    }
    const productId=String(entry.product_id||'');
    const basePlan=String(entry.plan_identifier||'');
    return products.find(x=>String(x?.planIdentifier||'')===productId&&String(x?.identifier||'')===basePlan)
      ||products.find(x=>String(x?.planIdentifier||'')===productId&&(!basePlan||String(x?.identifier||'')===basePlan))
      ||null;
  }

  async function loadProducts(options={}){
    const p=await ensureSupported();
    const entries=Array.isArray(options.products)?options.products:[];
    if(!entries.length)return [];
    const ids=[...new Set(entries.map(x=>String(x?.product_id||'')).filter(Boolean))];
    if(!ids.length)return [];
    const result=await p.getProducts({productIdentifiers:ids,productType:SUBS});
    const products=Array.isArray(result?.products)?result.products:[];
    return entries.map(entry=>{
      const product=matchProduct(entry,products);
      if(!product)return null;
      return {
        plan:String(entry.plan||''),
        productId:String(entry.product_id||''),
        planIdentifier:String(entry.plan_identifier||''),
        storeIdentifier:String(product.identifier||''),
        storePlanIdentifier:String(product.planIdentifier||''),
        offerToken:String(product.offerToken||''),
        title:String(product.title||''),
        description:String(product.description||''),
        priceString:String(product.priceString||''),
        currencyCode:String(product.currencyCode||''),
        price:Number(product.price)||0
      };
    }).filter(Boolean);
  }

  async function verificationError(error,data){
    let detail=data||null;
    if(!detail&&error?.context&&typeof error.context.json==='function'){
      try{detail=await error.context.json()}catch{}
    }
    const e=new Error(String(detail?.message||detail?.error||error?.message||'Store-Kauf konnte serverseitig nicht verifiziert werden.'));
    e.code=String(detail?.error||'store_verification_failed');
    e.status=Number(error?.context?.status||0)||0;
    return e;
  }

  async function verify({plan,productId,planIdentifier,companyId,environment,source,transaction}){
    const ctx=cloud();
    if(!ctx?.client||!ctx?.session||!ctx?.company?.id)throw new Error('Betriebskonto ist nicht verbunden.');
    if(String(ctx.company.id)!==String(companyId))throw new Error('Betriebskonto hat sich geändert. Bitte erneut versuchen.');
    const storeProvider=provider();
    if(!storeProvider)throw new Error('Unbekannte Store-Plattform.');
    const {data,error}=await ctx.client.functions.invoke('store-billing-verify',{body:{
      company_id:companyId,
      provider:storeProvider,
      environment:transactionEnvironment(transaction,environment),
      plan,
      product_id:productId,
      plan_identifier:planIdentifier||'',
      source:source||'purchase',
      transaction
    }});
    if(error)throw await verificationError(error,data);
    if(!data?.ok||data?.verified!==true){
      const e=new Error(String(data?.message||data?.error||'Store-Kauf wurde noch nicht serverseitig bestätigt.'));
      e.code=String(data?.error||'store_not_verified');
      throw e;
    }
    const allowedStatuses=new Set(['trial','active','past_due','grace_period','restricted','cancelled']);
    if(String(data.provider||'')!==storeProvider||String(data.plan||'')!==String(plan||'')||!allowedStatuses.has(String(data.status||''))||!String(data.event_id||'')){
      const e=new Error('Store-Serverantwort ist unvollständig oder passt nicht zur Transaktion.');
      e.code='store_verification_response_mismatch';
      throw e;
    }
    return data;
  }

  async function acknowledge(transaction,serverResult){
    const p=assertBridge();
    if(serverResult?.acknowledged===true)return;
    if(platform()==='android'&&transaction?.isAcknowledged===true)return;
    const token=platform()==='ios'?String(transaction?.transactionId||''):String(transaction?.purchaseToken||'');
    if(!token)throw new Error('Store-Transaktion kann nicht bestätigt werden.');
    await p.acknowledgePurchase({purchaseToken:token});
  }

  async function productForPurchase(entry){
    const loaded=await loadProducts({products:[entry]});
    return loaded[0]||null;
  }

  async function purchase(options={}){
    try{
      const expected=provider();
      if(!expected||expected!==String(options.provider||''))throw new Error('Falscher Store-Kanal für dieses Gerät.');
      const entry={plan:options.plan,product_id:options.productId,plan_identifier:options.planIdentifier||''};
      const storeProduct=await productForPurchase(entry);
      if(!storeProduct)throw new Error('Der Store-Tarif ist auf diesem Gerät nicht verfügbar.');
      if(platform()==='android'&&!storeProduct.planIdentifier)throw new Error('Google-Play-Base-Plan fehlt.');

      const p=assertBridge();
      const transaction=await p.purchaseProduct({
        productIdentifier:String(options.productId||''),
        planIdentifier:platform()==='android'?String(options.planIdentifier||''):undefined,
        offerToken:platform()==='android'&&storeProduct.offerToken?storeProduct.offerToken:undefined,
        productType:SUBS,
        appAccountToken:String(options.companyId||''),
        autoAcknowledgePurchases:false
      });
      if(!transaction)return {cancelled:true};
      const server=await verify({
        plan:options.plan,
        productId:options.productId,
        planIdentifier:options.planIdentifier||'',
        companyId:options.companyId,
        environment:options.environment,
        source:'purchase',
        transaction
      });
      await acknowledge(transaction,server);
      return {verified:true,transactionId:String(transaction.transactionId||''),server};
    }catch(error){
      if(isCancelled(error))return {cancelled:true};
      throw error;
    }
  }

  function catalogEntries(options={}){
    return Array.isArray(options.products)?options.products:[];
  }
  function entryForTransaction(transaction,entries){
    const productId=String(transaction?.productIdentifier||'');
    return entries.find(x=>String(x?.product_id||'')===productId)||null;
  }

  async function verifyRestoredTransaction(transaction,entry,options){
    const server=await verify({
      plan:entry.plan,
      productId:entry.product_id,
      planIdentifier:entry.plan_identifier||'',
      companyId:options.companyId,
      environment:options.environment,
      source:'restore',
      transaction
    });
    await acknowledge(transaction,server);
    return server;
  }

  async function restore(options={}){
    const p=await ensureSupported();
    const entries=catalogEntries(options);
    if(!entries.length)throw new Error('Store-Produkte sind noch nicht eingerichtet.');
    await p.restorePurchases();
    const result=await p.getPurchases({
      productType:SUBS,
      appAccountToken:String(options.companyId||''),
      onlyCurrentEntitlements:true
    });
    const purchases=Array.isArray(result?.purchases)?result.purchases:[];
    let verifiedCount=0;
    for(const transaction of purchases){
      const entry=entryForTransaction(transaction,entries);if(!entry)continue;
      await verifyRestoredTransaction(transaction,entry,options);
      verifiedCount++;
    }
    return {verifiedCount,purchaseCount:purchases.length};
  }

  async function manage(){
    const p=await ensureSupported();
    if(typeof p.manageSubscriptions!=='function')throw new Error('Store-Aboverwaltung ist nicht verfügbar.');
    await p.manageSubscriptions();
  }

  async function handleTransactionUpdate(transaction){
    try{
      if(platform()!=='ios'||!transaction)return;
      let state=globalThis.StoreBilling?._state?.()||{};
      let catalog=state.catalog||{};
      if(!catalog?.configured&&typeof globalThis.StoreBilling?.loadCatalog==='function'){
        await globalThis.StoreBilling.loadCatalog(true);
        state=globalThis.StoreBilling?._state?.()||{};
        catalog=state.catalog||{};
      }
      if(!catalog?.configured)return;
      const entry=entryForTransaction(transaction,catalog.products||[]);if(!entry)return;
      const companyId=cloud()?.company?.id||'';if(!companyId)return;
      const server=await verify({
        plan:entry.plan,productId:entry.product_id,planIdentifier:entry.plan_identifier||'',
        companyId,environment:catalog.environment,source:'transaction_update',transaction
      });
      await acknowledge(transaction,server);
      setTimeout(()=>globalThis.SubscriptionBilling?.refresh?.({silent:true}),500);
    }catch(error){
      // Never grant locally. A later Restore replays the current entitlement to the server.
      console.warn('Native Store transaction update not verified',textError(error,''));
    }
  }

  async function installListener(){
    if(listenerInstalled||platform()!=='ios')return;
    const p=native();if(!p?.addListener)return;
    listenerInstalled=true;
    try{
      await p.addListener('transactionUpdated',handleTransactionUpdate);
      await p.addListener('transactionVerificationFailed',payload=>console.warn('StoreKit transaction verification failed',payload?.transactionId||''));
    }catch(error){listenerInstalled=false;console.warn('StoreKit listener setup failed',textError(error,''))}
  }

  const adapter={BUILD,loadProducts,purchase,restore,manage};
  globalThis.APNativeStoreBilling=adapter;

  function register(){
    if(globalThis.StoreBilling?.registerAdapter){
      globalThis.StoreBilling.registerAdapter(adapter);
      installListener();
      return true;
    }
    return false;
  }
  if(!register()){
    let tries=0;const timer=setInterval(()=>{tries++;if(register()||tries>100)clearInterval(timer)},100);
  }
})();
