/* AngebotsPilot Native v0.3.5 – iOS/Android bridge helpers */
(function(){
  'use strict';

  if(!globalThis.__ANGEBOTSPILOT_NATIVE__) return;

  const BIO_KEY='angebotspilot_native_biometric_lock_v1';
  let authInFlight=false;
  let lastPhoto=null;

  const q=id=>document.getElementById(id);
  const toast=msg=>globalThis.toast?.(msg);
  const plugins=()=>globalThis.Capacitor?.Plugins||{};
  const plugin=name=>plugins()?.[name]||null;
  const enabled=()=>localStorage.getItem(BIO_KEY)==='1';
  const setEnabled=v=>localStorage.setItem(BIO_KEY,v?'1':'0');

  function safeError(err,fallback){
    const code=String(err?.code||'');
    if(['userCancel','appCancel','systemCancel'].includes(code)) return '';
    return err?.message||fallback;
  }

  async function hapticSuccess(){
    try{await plugin('Haptics')?.notification?.({type:'SUCCESS'})}catch(e){}
  }

  async function biometryInfo(){
    const bio=plugin('BiometricAuth');
    if(!bio?.checkBiometry) return {isAvailable:false,deviceIsSecure:false,biometryType:'none',reason:'Biometrie-Plugin nicht verfügbar'};
    try{return await bio.checkBiometry()}catch(e){return {isAvailable:false,deviceIsSecure:false,biometryType:'none',reason:e?.message||'Nicht verfügbar'}}
  }

  function biometryLabel(info){
    const t=String(info?.biometryType||'').toLowerCase();
    if(t.includes('face')) return 'Face ID';
    if(t.includes('touch')) return 'Touch ID';
    if(t.includes('finger')) return 'Fingerabdruck';
    return 'Biometrie';
  }

  async function authenticate(reason='AngebotsPilot entsperren'){
    const bio=plugin('BiometricAuth');
    if(!bio?.authenticate) throw new Error('Biometrische Anmeldung ist auf diesem Gerät nicht verfügbar.');
    await bio.authenticate({
      reason,
      cancelTitle:'Abbrechen',
      allowDeviceCredential:true,
      iosFallbackTitle:'Code verwenden',
      androidTitle:'AngebotsPilot entsperren',
      androidSubtitle:'Bestätige deine Identität',
      androidConfirmationRequired:false
    });
  }

  async function enableBiometricLock(){
    const info=await biometryInfo();
    if(!info?.isAvailable){
      toast(info?.deviceIsSecure?'Biometrie ist nicht eingerichtet. Bitte zuerst Face ID/Touch ID in den iPhone-Einstellungen aktivieren.':'Auf diesem Gerät ist keine sichere Biometrie verfügbar.');
      renderNativeSecurity(info);return false;
    }
    try{
      await authenticate('Face ID / Touch ID für AngebotsPilot aktivieren');
      setEnabled(true);await hapticSuccess();renderNativeSecurity(info);
      toast(`✓ ${biometryLabel(info)} für die App-Sperre aktiviert`);return true;
    }catch(e){const msg=safeError(e,'Biometrie konnte nicht aktiviert werden.');if(msg)toast(msg);return false}
  }

  async function disableBiometricLock(){
    setEnabled(false);renderNativeSecurity(await biometryInfo());toast('Biometrische App-Sperre deaktiviert.');
  }

  async function toggleBiometricLock(){return enabled()?disableBiometricLock():enableBiometricLock()}

  async function unlockWithBiometrics(auto=false){
    if(authInFlight||!enabled())return false;
    authInFlight=true;
    try{
      await authenticate('AngebotsPilot entsperren');
      globalThis.SecurityCenter?.unlockNative?.();
      await hapticSuccess();
      return true;
    }catch(e){
      const msg=safeError(e,'Entsperren nicht möglich.');
      if(msg&&!auto){const el=q('securityLockError');if(el)el.textContent=msg;else toast(msg)}
      return false;
    }finally{authInFlight=false}
  }

  function securityBlock(){
    const host=q('securityCenterCard');if(!host||q('nativeBiometricBlock'))return;
    const block=document.createElement('div');block.className='securityFeatureBlock nativeSecurityBlock';block.id='nativeBiometricBlock';
    block.innerHTML=`<div class="securityFeatureTitle"><span>📱</span><div><b>App-Sperre</b><small>Face ID / Touch ID direkt auf diesem Gerät</small></div></div><p class="mini" id="nativeBiometricInfo">Biometrie wird geprüft …</p><button class="btn primary" id="nativeBiometricToggle" type="button" onclick="NativeFeatures.toggleBiometricLock()">Prüfen …</button>`;
    const grid=host.querySelector('.securitySummaryGrid');
    if(grid?.nextSibling)host.insertBefore(block,grid.nextSibling);else host.append(block);
  }

  async function renderNativeSecurity(given){
    securityBlock();
    const info=given||await biometryInfo();
    const text=q('nativeBiometricInfo'),btn=q('nativeBiometricToggle');
    if(text){
      if(info?.isAvailable) text.textContent=enabled()?`${biometryLabel(info)} ist für die automatische App-Sperre aktiv. Biometrische Daten verlassen dein Gerät nicht.`:`${biometryLabel(info)} ist verfügbar. Die bestehende Auto-Sperre kann damit ohne Passwort entsperrt werden.`;
      else text.textContent='Auf diesem Gerät ist aktuell keine verfügbare Face ID / Touch ID-Anmeldung eingerichtet.';
    }
    if(btn){btn.disabled=!info?.isAvailable&&!enabled();btn.textContent=enabled()?'Biometrie deaktivieren':`${biometryLabel(info)} aktivieren`}
    patchLockButton(info);
  }

  function patchLockButton(info){
    const btn=document.querySelector('#securityLockOverlay [data-passkey-login]');if(!btn)return;
    if(enabled()){
      btn.hidden=false;btn.classList.remove('hidden');btn.disabled=false;
      btn.textContent=`🔐 Mit ${biometryLabel(info)} entsperren`;
      btn.onclick=()=>unlockWithBiometrics(false);
    }
  }

  function lockObserver(){
    const overlay=q('securityLockOverlay');if(!overlay)return;
    const obs=new MutationObserver(async()=>{
      const visible=!overlay.hidden&&!overlay.classList.contains('hidden');
      if(!visible)return;
      const info=await biometryInfo();patchLockButton(info);
      if(enabled()&&info?.isAvailable)setTimeout(()=>unlockWithBiometrics(true),180);
    });
    obs.observe(overlay,{attributes:true,attributeFilter:['hidden','class']});
  }

  async function takePhoto(editable=false){
    const camera=plugin('Camera');if(!camera)throw new Error('Kamera ist nicht verfügbar.');
    if(camera.takePhoto){
      return camera.takePhoto({quality:88,editable:editable?'in-app':'none',cameraDirection:'REAR',includeMetadata:false});
    }
    if(camera.getPhoto){
      return camera.getPhoto({quality:88,allowEditing:!!editable,resultType:'uri',source:'CAMERA',direction:'REAR',correctOrientation:true,saveToGallery:false});
    }
    throw new Error('Kamera-Funktion wird von diesem Build nicht unterstützt.');
  }

  async function choosePhoto(){
    const camera=plugin('Camera');if(!camera)throw new Error('Fotomediathek ist nicht verfügbar.');
    if(camera.chooseFromGallery){const res=await camera.chooseFromGallery({quality:90,limit:1});return res?.results?.[0]||null}
    if(camera.getPhoto)return camera.getPhoto({quality:90,allowEditing:false,resultType:'uri',source:'PHOTOS'});
    throw new Error('Fotomediathek wird von diesem Build nicht unterstützt.');
  }

  async function mediaToFile(media,prefix='Foto'){
    if(!media)throw new Error('Kein Bild ausgewählt.');
    const source=media.webPath||media.uri||media.path;if(!source)throw new Error('Bilddatei konnte nicht gelesen werden.');
    const response=await fetch(source);if(!response.ok)throw new Error('Bilddatei konnte nicht geladen werden.');
    const blob=await response.blob();
    const ext=(blob.type||'image/jpeg').includes('png')?'png':'jpg';
    const stamp=new Date().toISOString().replace(/[:.]/g,'-');
    return new File([blob],`${prefix}-${stamp}.${ext}`,{type:blob.type||'image/jpeg',lastModified:Date.now()});
  }

  async function captureCustomerPhoto(){
    try{
      const media=await takePhoto(false),file=await mediaToFile(media,'Kundenfoto');lastPhoto=media;
      if(typeof globalThis.addCustomerGalleryPhotos!=='function')throw new Error('Kundenakte ist noch nicht bereit.');
      await globalThis.addCustomerGalleryPhotos({target:{files:[file],value:''}});await hapticSuccess();
    }catch(e){const msg=safeError(e,'Foto konnte nicht aufgenommen werden.');if(msg)toast(msg)}
  }

  async function scanCustomerDocument(){
    try{
      const media=await takePhoto(true),file=await mediaToFile(media,'Dokument-Scan');lastPhoto=media;
      if(typeof globalThis.addCustomerDocuments!=='function')throw new Error('Kundenakte ist noch nicht bereit.');
      await globalThis.addCustomerDocuments({target:{files:[file],value:''}});await hapticSuccess();
    }catch(e){const msg=safeError(e,'Dokument konnte nicht aufgenommen werden.');if(msg)toast(msg)}
  }

  async function captureStandalone(editable=false){
    try{
      const media=await takePhoto(editable);lastPhoto=media;
      const preview=q('nativeMediaPreview');if(preview){preview.src=media.webPath||media.uri||media.path||'';preview.hidden=!preview.src}
      const share=q('nativeSharePhoto');if(share)share.hidden=false;
      toast(editable?'✓ Dokument aufgenommen':'✓ Foto aufgenommen');
    }catch(e){const msg=safeError(e,'Aufnahme nicht möglich.');if(msg)toast(msg)}
  }

  async function chooseStandalone(){
    try{
      const media=await choosePhoto();if(!media)return;lastPhoto=media;
      const preview=q('nativeMediaPreview');if(preview){preview.src=media.webPath||media.uri||media.path||'';preview.hidden=!preview.src}
      const share=q('nativeSharePhoto');if(share)share.hidden=false;
    }catch(e){const msg=safeError(e,'Foto konnte nicht ausgewählt werden.');if(msg)toast(msg)}
  }

  async function shareLastPhoto(){
    if(!lastPhoto)return toast('Noch kein Foto aufgenommen.');
    const share=plugin('Share');if(!share?.share)return toast('Teilen ist nicht verfügbar.');
    const uri=lastPhoto.uri||lastPhoto.path||lastPhoto.webPath;
    try{await share.share({title:'AngebotsPilot',files:uri?[uri]:undefined,url:uri||undefined,dialogTitle:'Foto teilen'})}catch(e){const msg=safeError(e,'Foto konnte nicht geteilt werden.');if(msg)toast(msg)}
  }

  function safeFileName(name='Datei'){return String(name||'Datei').replace(/[^a-zA-Z0-9._-]+/g,'_').slice(-120)||'Datei'}

  async function blobToBase64(blob){
    return await new Promise((resolve,reject)=>{
      const reader=new FileReader();
      reader.onerror=()=>reject(reader.error||new Error('Datei konnte nicht gelesen werden.'));
      reader.onload=()=>resolve(String(reader.result||'').split(',')[1]||'');
      reader.readAsDataURL(blob);
    });
  }

  async function shareBlobFile(blob,fileName='Datei',dialogTitle='Datei teilen'){
    const fs=plugin('Filesystem'),share=plugin('Share');
    if(!fs?.writeFile||!share?.share)throw new Error('System-Teilen ist auf diesem Gerät nicht verfügbar.');
    if(!(blob instanceof Blob))throw new Error('Ungültige Datei.');
    const path=`Chat-${Date.now()}-${safeFileName(fileName)}`;
    let written=null;
    try{
      written=await fs.writeFile({path,data:await blobToBase64(blob),directory:'CACHE'});
      await share.share({title:fileName||'AngebotsPilot',files:[written.uri],dialogTitle});
      await hapticSuccess();
      return true;
    }finally{
      if(written?.uri){try{await fs.deleteFile?.({path,directory:'CACHE'})}catch(e){}}
    }
  }

  async function shareBackup(){
    const fs=plugin('Filesystem'),share=plugin('Share');
    if(!fs?.writeFile||!share?.share)return toast('Datei-Teilen ist auf diesem Gerät nicht verfügbar.');
    try{
      const stamp=new Date().toISOString().slice(0,10),name=`AngebotsPilot-Backup-${stamp}.json`;
      const payload=JSON.stringify(globalThis.data||{},null,2);
      const written=await fs.writeFile({path:name,data:payload,directory:'CACHE',encoding:'utf8'});
      await share.share({title:'AngebotsPilot Backup',text:'Datensicherung aus AngebotsPilot',files:[written.uri],dialogTitle:'Backup sichern oder teilen'});
      await hapticSuccess();
    }catch(e){const msg=safeError(e,'Backup konnte nicht geteilt werden.');if(msg)toast(msg)}
  }

  async function nativeContactSelect(){
    const contacts=plugin('Contacts');if(!contacts?.pickContact)throw new DOMException('Kontakte nicht verfügbar','NotSupportedError');
    const result=await contacts.pickContact({projection:{name:true,phones:true,emails:true}});
    const c=result?.contact||result?.contacts?.[0]||null;if(!c)return[];
    const display=c.name?.display||[c.name?.given,c.name?.family].filter(Boolean).join(' ')||c.organizationName||'';
    const emails=(c.emails||c.emailAddresses||[]).map(x=>x?.address||x?.value||'').filter(Boolean);
    const tels=(c.phones||c.phoneNumbers||[]).map(x=>x?.number||x?.value||'').filter(Boolean);
    return [{name:[display],email:emails,tel:tels}];
  }

  function installContactsShim(){
    try{
      const nav=globalThis.navigator;
      if(!nav.contacts)Object.defineProperty(nav,'contacts',{value:{},configurable:true});
      if(!nav.contacts.select)nav.contacts.select=()=>nativeContactSelect();
    }catch(e){console.warn('Native contacts shim',e)}
  }

  function injectCustomerButtons(){
    const host=document.querySelector('#customerDetail .customerFileActions');if(!host||q('nativeCustomerCameraBtn'))return;
    const photo=document.createElement('button');photo.type='button';photo.className='customerFileBtn nativeCustomerAction';photo.id='nativeCustomerCameraBtn';photo.onclick=captureCustomerPhoto;
    photo.innerHTML='<span>📷</span><b>Foto aufnehmen</b><small>Direkt mit der Geräte-Kamera</small>';
    const scan=document.createElement('button');scan.type='button';scan.className='customerFileBtn nativeCustomerAction owner-office-only';scan.id='nativeCustomerScanBtn';scan.onclick=scanCustomerDocument;
    scan.innerHTML='<span>📄</span><b>Dokument scannen</b><small>Fotografieren & zuschneiden</small>';
    host.append(photo,scan);globalThis.applyRoleUI?.();
  }

  function toolsModal(){
    if(q('nativeToolsModal'))return;
    const modal=document.createElement('div');modal.id='nativeToolsModal';modal.className='nativeToolsBackdrop hidden';modal.innerHTML=`<div class="nativeToolsSheet"><div class="nativeToolsHandle"></div><div class="sectionTitle"><div><span class="securityBadge">NATIV</span><h2>Native Werkzeuge</h2><p class="mini">Funktionen, die nur in der echten App verfügbar sind.</p></div><button class="btn small" onclick="NativeFeatures.closeTools()">Schließen</button></div><div class="nativeToolsGrid"><button class="nativeTool" onclick="NativeFeatures.captureStandalone(false)"><span>📷</span><b>Foto aufnehmen</b><small>Geräte-Kamera</small></button><button class="nativeTool" onclick="NativeFeatures.captureStandalone(true)"><span>📄</span><b>Dokument aufnehmen</b><small>Zuschneiden möglich</small></button><button class="nativeTool" onclick="NativeFeatures.chooseStandalone()"><span>🖼️</span><b>Fotomediathek</b><small>Bild auswählen</small></button><button class="nativeTool" onclick="NativeFeatures.shareBackup()"><span>⬆️</span><b>Backup teilen</b><small>Datei sichern oder senden</small></button></div><div class="nativePreviewCard"><img id="nativeMediaPreview" hidden alt="Vorschau"><button class="btn" id="nativeSharePhoto" hidden onclick="NativeFeatures.shareLastPhoto()">Teilen …</button></div><div class="notice nativePushNotice">🔔 Native Push-Nachrichten aktivieren wir beim TestFlight-/Apple-Signierungs-Schritt. Die In-App-Benachrichtigungen funktionieren weiterhin.</div></div>`;
    modal.addEventListener('click',e=>{if(e.target===modal)closeTools()});document.body.append(modal);
  }

  function injectMoreTile(){
    const grid=document.querySelector('#more .quickGrid');if(!grid||q('nativeToolsQuick'))return;
    const btn=document.createElement('button');btn.className='quick';btn.id='nativeToolsQuick';btn.onclick=openTools;
    btn.innerHTML='<span class="emoji">📱</span><b>Geräte-Funktionen</b><small>Face ID, Kamera, Kontakte & Teilen</small>';
    grid.append(btn);
  }

  function injectStyle(){
    if(q('nativeFeaturesStyle'))return;
    const s=document.createElement('style');s.id='nativeFeaturesStyle';s.textContent=`
      .nativeToolsBackdrop{position:fixed;inset:0;background:rgba(0,0,0,.65);z-index:10050;display:flex;align-items:flex-end;justify-content:center;padding:0}.nativeToolsBackdrop.hidden{display:none}.nativeToolsSheet{width:min(720px,100%);max-height:88vh;overflow:auto;background:var(--card,#131820);border:1px solid var(--border,#293240);border-radius:28px 28px 0 0;padding:18px 18px calc(22px + env(safe-area-inset-bottom));box-shadow:0 -18px 60px rgba(0,0,0,.45)}.nativeToolsHandle{width:48px;height:5px;border-radius:9px;background:#667080;margin:0 auto 16px}.nativeToolsGrid{display:grid;grid-template-columns:1fr 1fr;gap:12px}.nativeTool{min-height:126px;border:1px solid var(--border,#293240);background:var(--card2,#1b222c);color:inherit;border-radius:22px;padding:16px;text-align:left;display:flex;flex-direction:column;gap:5px}.nativeTool span{font-size:28px}.nativeTool b{font-size:16px}.nativeTool small{color:var(--muted,#9aa4b4)}.nativePreviewCard{margin-top:14px;display:grid;gap:10px}.nativePreviewCard img{width:100%;max-height:320px;object-fit:contain;border-radius:18px;background:#090b0e}.nativePushNotice{margin-top:14px}.nativeCustomerAction{border:1px solid var(--border,#293240);background:var(--card2,#1b222c);color:inherit;text-align:left;cursor:pointer}.nativeSecurityBlock{border-color:rgba(199,255,34,.28)!important}.native-app .top{padding-top:max(14px,env(safe-area-inset-top))}
      @media(max-width:420px){.nativeToolsGrid{grid-template-columns:1fr 1fr}.nativeTool{min-height:118px;padding:14px}.customerFileActions{grid-template-columns:1fr 1fr}}
    `;document.head.append(s);
  }

  function openTools(){toolsModal();q('nativeToolsModal')?.classList.remove('hidden')}
  function closeTools(){q('nativeToolsModal')?.classList.add('hidden')}

  async function init(){
    injectStyle();installContactsShim();injectMoreTile();injectCustomerButtons();toolsModal();securityBlock();lockObserver();
    await renderNativeSecurity();
    // Some app renders replace role classes after startup; make sure native controls are present afterwards too.
    setTimeout(()=>{injectCustomerButtons();renderNativeSecurity().catch(()=>{})},1200);
  }

  globalThis.NativeFeatures={
    init,biometryInfo,toggleBiometricLock,enableBiometricLock,disableBiometricLock,unlockWithBiometrics,
    captureCustomerPhoto,scanCustomerDocument,captureStandalone,chooseStandalone,shareLastPhoto,shareBlobFile,shareBackup,
    openTools,closeTools
  };

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();
