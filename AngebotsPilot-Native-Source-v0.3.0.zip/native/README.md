# AngebotsPilot Native iOS/Android v0.3.0

Dieser Native-Build nutzt weiterhin die bestehende AngebotsPilot-Web-App als fachliche Codebasis und ergänzt native Gerätefunktionen sowie die vorbereitete Store-Billing-Bridge.

## Neu in v0.3.0
- Gemeinsame native Abo-Schnittstelle für Apple App Store und Google Play.
- `@capgo/native-purchases` 8.7.0 für StoreKit 2 / Google Play Billing.
- Native Storepreise werden aus dem jeweiligen Store geladen; kein freigeschalteter Kauf verlässt sich auf hart codierte Storepreise.
- Kaufbelege werden an `store-billing-verify` gesendet. Die App selbst vergibt niemals ein Abo-Recht.
- Direkte Käufe laufen mit `autoAcknowledgePurchases:false`; Bestätigung erfolgt erst nach erfolgreicher Serverprüfung.
- Restore-Pfad prüft aktuelle Entitlements erneut serverseitig.
- iOS-Transaction-Updates werden an die Serverprüfung weitergereicht.
- Android-Unterbau und Capacitor-Android-Abhängigkeit ergänzt.

## Sicherheitszustand vor den Store-Konten
Apple- und Google-Käufe bleiben absichtlich gesperrt, solange der serverseitige Provider-Gate nicht aktiviert wurde. Produkt-IDs alleine reichen nicht aus. Dadurch kann vor Einrichtung der echten Store-Credentials kein versehentlicher Kauf freigeschaltet werden.

## Bestehende Native-Funktionen
- Face ID / Touch ID bzw. Gerätebiometrie für die App-Sperre.
- Kamera direkt in der Kundenakte.
- Dokumentaufnahme mit Zuschneiden als einfacher Scan-Workflow.
- Nativer Kontakt-Picker.
- Native Datei-/Share-Funktion für Backups und Bilder.
- Haptisches Erfolgsfeedback.

## Bewusst noch nicht live
- Apple App Store Server API v2 Verifikation mit finalen Apple-Credentials.
- Google Play Developer API Verifikation mit finalem Service Account.
- Echte Apple-/Google-Produkt-IDs.
- Signierte TestFlight-/Play-Internal-Test-Builds.
- Remote-Push über APNs/FCM.

## Architektur
- Root-Dateien des Repositories bleiben die Web-Quelle.
- `prepare:web` kopiert sie nach `native/www`.
- `injected/native-features.js` enthält Gerätefunktionen.
- `injected/native-store-billing.js` enthält nur den Native-Store-Adapter; die zentrale Abo-Logik bleibt in `store-billing.js`.
- Der PWA-Service-Worker wird im Native-Bundle entfernt.
- Store-Entitlements kommen ausschließlich aus dem serverseitig verifizierten `company_subscriptions`-Status.

## Bundle-/Package-ID
`com.harunxaa.angebotspilot`

## Store-Billing v0.3.0 – harte Freigaberegeln

- Ein Store-Kauf wird nur vom Web-Layer angeboten, wenn der serverseitige Katalog `verification_ready=true` **und** den erwarteten Verifikationsmodus meldet.
- `autoAcknowledgePurchases=false`: iOS/Android werden erst nach erfolgreicher Server-Verifikation abgeschlossen/bestätigt.
- iOS `transactionUpdated` lädt bei Bedarf zuerst den aktuellen Katalog, verifiziert serverseitig und beendet die StoreKit-Transaktion erst danach.
- Die Transaktionsumgebung (`Sandbox`/`Production`) überschreibt beim Server-Verify die Build-Vorgabe, sofern StoreKit sie liefert.
- Android `com.android.vending.BILLING` wird durch `scripts/patch-android.mjs` nach `cap sync android` sichergestellt.
- Für einen späteren Sandbox-Build kann `AP_NATIVE_STORE_ENVIRONMENT=sandbox` gesetzt werden. Ohne Vorgabe bleibt `production`.
- Solange Apple-/Google-Serververifikation und echte Store-Produkte nicht aktiviert sind, bleiben Kauf und Restore gesperrt. Bestehende Stripe-Web-Abos behalten ihren Zugang.
