import { copyFile, readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const nativeDir = path.resolve(here, '..');
const config = JSON.parse(await readFile(path.join(nativeDir, 'capacitor.config.json'), 'utf8'));
const iosRoot = path.join(nativeDir, 'ios', 'App');
const pbxPath = path.join(iosRoot, 'App.xcodeproj', 'project.pbxproj');
const plistPath = path.join(iosRoot, 'App', 'Info.plist');

let pbx = await readFile(pbxPath, 'utf8');
pbx = pbx.replace(/PRODUCT_BUNDLE_IDENTIFIER = [^;]+;/g, `PRODUCT_BUNDLE_IDENTIFIER = ${config.appId};`);
pbx = pbx.replace(/TARGETED_DEVICE_FAMILY = "1,2";/g, 'TARGETED_DEVICE_FAMILY = 1;');
pbx = pbx.replace(/MARKETING_VERSION = [^;]+;/g, 'MARKETING_VERSION = 0.3.6;');
const buildNumber = process.env.CM_BUILD_NUMBER || '1';
pbx = pbx.replace(/CURRENT_PROJECT_VERSION = [^;]+;/g, `CURRENT_PROJECT_VERSION = ${buildNumber};`);

const privacySource=path.join(nativeDir,'privacy','PrivacyInfo.xcprivacy');
const privacyTarget=path.join(iosRoot,'App','PrivacyInfo.xcprivacy');
await copyFile(privacySource,privacyTarget);
if(!pbx.includes('PrivacyInfo.xcprivacy')){
  const buildId='A1132110000000000000001';
  const fileId='A1132110000000000000002';
  pbx=pbx.replace('/* Begin PBXBuildFile section */',`/* Begin PBXBuildFile section */\n\t\t${buildId} /* PrivacyInfo.xcprivacy in Resources */ = {isa = PBXBuildFile; fileRef = ${fileId} /* PrivacyInfo.xcprivacy */; };`);
  pbx=pbx.replace('/* Begin PBXFileReference section */',`/* Begin PBXFileReference section */\n\t\t${fileId} /* PrivacyInfo.xcprivacy */ = {isa = PBXFileReference; lastKnownFileType = text.xml; path = PrivacyInfo.xcprivacy; sourceTree = "<group>"; };`);
  const appGroup=/([A-F0-9]{24} \/\* App \*\/ = \{[\s\S]*?isa = PBXGroup;[\s\S]*?children = \(\n)([\s\S]*?)(\n\s*\);[\s\S]*?path = App;)/;
  if(!appGroup.test(pbx))throw new Error('Privacy manifest: App PBXGroup nicht gefunden.');
  pbx=pbx.replace(appGroup,(all,head,children,tail)=>`${head}\t\t\t\t${fileId} /* PrivacyInfo.xcprivacy */,${children}${tail}`);
  const resources=/(isa = PBXResourcesBuildPhase;[\s\S]*?files = \(\n)([\s\S]*?)(\n\s*\);)/;
  if(!resources.test(pbx))throw new Error('Privacy manifest: Resources Build Phase nicht gefunden.');
  pbx=pbx.replace(resources,(all,head,files,tail)=>`${head}\t\t\t\t${buildId} /* PrivacyInfo.xcprivacy in Resources */,${files}${tail}`);
}
if(!pbx.includes('PrivacyInfo.xcprivacy in Resources'))throw new Error('Privacy manifest wurde nicht als iOS Resource eingebunden.');
await writeFile(pbxPath, pbx, 'utf8');

let plist = await readFile(plistPath, 'utf8');
plist = plist.replace(
  /<key>CFBundleDisplayName<\/key>\s*<string>[^<]*<\/string>/,
  '<key>CFBundleDisplayName</key>\n\t<string>AngebotsPilot</string>'
);
plist = plist.replace(
  /<key>UISupportedInterfaceOrientations<\/key>\s*<array>[\s\S]*?<\/array>/,
  '<key>UISupportedInterfaceOrientations</key>\n\t<array>\n\t\t<string>UIInterfaceOrientationPortrait</string>\n\t</array>'
);

function upsertPlistString(key,value){
  const esc=value.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;');
  const re=new RegExp(`<key>${key}<\\/key>\\s*<string>[^<]*<\\/string>`);
  const block=`<key>${key}</key>\n\t<string>${esc}</string>`;
  if(re.test(plist)) plist=plist.replace(re,block);
  else plist=plist.replace('</dict>',`\t${block}\n</dict>`);
}

upsertPlistString('NSFaceIDUsageDescription','Face ID schützt den Zugriff auf deine Kunden- und Betriebsdaten in AngebotsPilot.');
upsertPlistString('NSCameraUsageDescription','AngebotsPilot nutzt die Kamera, damit du Baustellenfotos und Dokumente direkt erfassen kannst.');
upsertPlistString('NSPhotoLibraryUsageDescription','AngebotsPilot greift nur auf von dir ausgewählte Fotos zu, um sie einer Kundenakte hinzuzufügen.');
upsertPlistString('NSContactsUsageDescription','AngebotsPilot öffnet den Kontakt-Picker, damit du ausgewählte Kontakte als Kunden übernehmen kannst.');
upsertPlistString('NSMicrophoneUsageDescription','AngebotsPilot nutzt das Mikrofon nur, wenn du aktiv ein Sprachmemo für eine Baustelle oder ein Angebot aufnimmst.');
await writeFile(plistPath, plist, 'utf8');

const assets = path.join(nativeDir, 'assets');
const appAssets = path.join(iosRoot, 'App', 'Assets.xcassets');
await copyFile(path.join(assets, 'AppIcon-1024.png'), path.join(appAssets, 'AppIcon.appiconset', 'AppIcon-512@2x.png'));
for (const name of ['splash-2732x2732.png', 'splash-2732x2732-1.png', 'splash-2732x2732-2.png']) {
  await copyFile(path.join(assets, 'Splash-2732.png'), path.join(appAssets, 'Splash.imageset', name));
}

console.log(`iOS project patched for ${config.appId}, native v0.3.6, build ${buildNumber}.`);
