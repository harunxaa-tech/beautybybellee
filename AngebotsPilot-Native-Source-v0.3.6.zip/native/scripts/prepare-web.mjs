import { cp, mkdir, readdir, readFile, rm, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const nativeDir = path.resolve(here, '..');
const repoRoot = path.resolve(nativeDir, '..');
const outDir = path.join(nativeDir, 'www');

const allowedExtensions = new Set(['.html', '.css', '.js', '.json', '.svg']);
const ignoredRootFiles = new Set(['codemagic.yaml']);
const storeEnvironment = String(process.env.AP_NATIVE_STORE_ENVIRONMENT || 'production').toLowerCase();
if (!['sandbox', 'production'].includes(storeEnvironment)) {
  throw new Error('AP_NATIVE_STORE_ENVIRONMENT muss sandbox oder production sein.');
}

await rm(outDir, { recursive: true, force: true });
await mkdir(outDir, { recursive: true });

const entries = await readdir(repoRoot, { withFileTypes: true });
for (const entry of entries) {
  if (!entry.isFile()) continue;
  if (ignoredRootFiles.has(entry.name)) continue;
  const ext = path.extname(entry.name).toLowerCase();
  if (!allowedExtensions.has(ext)) continue;
  await cp(path.join(repoRoot, entry.name), path.join(outDir, entry.name));
}

await cp(path.join(nativeDir, 'injected', 'native-features.js'), path.join(outDir, 'native-features.js'));
await cp(path.join(nativeDir, 'injected', 'native-store-billing.js'), path.join(outDir, 'native-store-billing.js'));

const indexPath = path.join(outDir, 'index.html');
let html = await readFile(indexPath, 'utf8');

// Native builds do not use the PWA service worker. Keeping it active in WKWebView
// can create stale asset behavior and makes native updates harder to reason about.
html = html.replace(/<script>if\("serviceWorker" in navigator\)[\s\S]*?<\/script>/g, '');
html = html.replace(/<link\s+rel="manifest"[^>]*>/gi, '');
html = html.replace(
  '</head>',
  '<meta name="format-detection" content="telephone=no">\n' +
  `<script>window.__ANGEBOTSPILOT_NATIVE__=true;window.__AP_NATIVE_PLATFORM__=(window.Capacitor?.getPlatform?.()||"");window.__AP_NATIVE_STORE_ENVIRONMENT__=${JSON.stringify(storeEnvironment)};document.documentElement.classList.add("native-app");</script>\n` +
  '</head>'
);
html = html.replace(
  '</body>',
  '<script src="native-features.js" defer></script>\n<script src="native-store-billing.js" defer></script>\n</body>'
);
await writeFile(indexPath, html, 'utf8');

// Native Face ID unlock needs one safe bridge into the existing lock state. This is
// applied only to the copied native bundle; the GitHub Pages/PWA source stays unchanged.
const securityPath = path.join(outDir, 'security.js');
let security = await readFile(securityPath, 'utf8');
security = security.replace(
  "globalThis.SecurityCenter={setClient,attach,detach,render:renderSecurity,checkLock};",
  "globalThis.SecurityCenter={setClient,attach,detach,render:renderSecurity,checkLock,unlockNative:()=>unlockApp(true)};"
);
await writeFile(securityPath, security, 'utf8');

const required = ['index.html', 'style.css', 'script.js', 'cloud-config.js', 'cloud-auth.js', 'security.js', 'chat-voice.css', 'smart-search.css', 'i18n.js', 'smart-search.js', 'voice-core.js', 'chat-compliance.js', 'job-chat.js', 'offer-voice.js', 'native-features.js', 'native-store-billing.js'];
for (const name of required) {
  try { await readFile(path.join(outDir, name)); }
  catch { throw new Error(`Native web bundle incomplete: ${name} fehlt.`); }
}

if (!security.includes('unlockNative')) throw new Error('Native Security bridge konnte nicht eingebaut werden.');
if (!html.includes('native-features.js')) throw new Error('Native Features Script fehlt im Native-Bundle.');
if (!html.includes('native-store-billing.js')) throw new Error('Native Store-Billing Script fehlt im Native-Bundle.');
console.log(`Native web bundle ready: ${outDir}`);
