# AngebotsPilot Native iOS/Android v0.3.6

Dieser Native-Build nutzt weiterhin die bestehende AngebotsPilot-Web-App als fachliche Codebasis und ergänzt native Gerätefunktionen sowie die vorbereitete Store-Billing-Bridge.

## Neu in v0.3.6

- Globale Smart Search aus v11.32.8 ist Pflichtbestandteil des nativen Web-Bundles (`smart-search.js` + `smart-search.css`).
- Suche bleibt lokal/offline und erzeugt keine KI-Kosten.
- Mehrsprachige Benutzeroberfläche (DE/EN/PL/RO/HR/BS/SR/FR/IT/TR) mit benutzerspezifischer Cloud-Sprache.
- `i18n.js` ist Pflichtbestandteil des Native-Web-Bundles; Kundendaten sowie Rechnungs-/Rechtstexte werden nicht ungeprüft automatisch übersetzt.
- Mikrofon-Berechtigungen für Baustellenchat- und Angebots-Sprachmemos auf iOS/Android vorbereitet.
- Der Web-Bundle-Workflow übernimmt die gemeinsame Voice-Komponente; Aufnahme bleibt nutzergesteuert.
- KI-Transkription/Übersetzung bleibt serverseitig kosten-/consent-gated und enthält keinen API-Schlüssel im Native-Bundle.
- Voice-Pipeline: `gpt-transcribe` für Sprache→Text und serverseitig konfiguriertes `gpt-6-astra` für kontextbezogene Übersetzung/Angebotsvorschläge; aktuell deaktiviert, bis API-Kosten bewusst freigeschaltet werden.
- Native Store-Bridge auf der bestehenden v0.3.0-Basis weitergehärtet; kein Neuaufbau.
- Serverantwort wird vor Finish/Acknowledge zusätzlich auf Provider, Tarif, Status und Event-ID gebunden.
- Die echte Apple-App-Store-Server- und Google-Play-Developer-API-Verifikation ist serverseitig implementiert; Freischaltung bleibt bis zu echten Store-Credentials/Produkten gesperrt.
- `@capgo/native-purchases` 8.7.0 für StoreKit 2 / Google Play Billing.
- Native Storepreise werden aus dem jeweiligen Store geladen; kein freigeschalteter Kauf verlässt sich auf hart codierte Storepreise.
- Kaufbelege werden an `store-billing-verify` gesendet. Die App selbst vergibt niemals ein Abo-Recht.
- Direkte Käufe laufen mit `autoAcknowledgePurchases:false`; Bestätigung erfolgt erst nach erfolgreicher Serverprüfung.
- Restore-Pfad prüft aktuelle Entitlements erneut serverseitig.
- iOS-Transaction-Updates werden an die Serverprüfung weitergereicht.
- Android-Unterbau und Capacitor-Android-Abhängigkeit ergänzt.

## Sicherheitszustand vor den Store-Konten
Apple- und Google-Käufe bleiben absichtlich gesperrt, solange der serverseitige Provider-Gate nicht aktiviert wurde. Produkt-IDs alleine reichen nicht aus. Dadurch kann vor Einrichtung der echten Store-Credentials kein versehentlicher Kauf freigeschaltet werden.

## Bestehende Native-Funktionen
- Face ID / Touch ID bzw. Gerätebiometrie für die App-Sperre.
- Kamera direkt in der Kundenakte.
- Dokumentaufnahme mit Zuschneiden als einfacher Scan-Workflow.
- Nativer Kontakt-Picker.
- Native Datei-/Share-Funktion für Backups und Bilder.
- Haptisches Erfolgsfeedback.

## Bewusst noch nicht live
- Finale Apple-Credentials / Root-Zertifikate im Server-Secret-Store.
- Finaler Google-Play-Service-Account im Server-Secret-Store.
- Echte Apple-/Google-Produkt-IDs.
- Signierte TestFlight-/Play-Internal-Test-Builds.
- Remote-Push über APNs/FCM.

## Architektur
- Root-Dateien des Repositories bleiben die Web-Quelle.
- `prepare:web` kopiert sie nach `native/www`.
- `injected/native-features.js` enthält Gerätefunktionen.
- `injected/native-store-billing.js` enthält nur den Native-Store-Adapter; die zentrale Abo-Logik bleibt in `store-billing.js`.
- Der PWA-Service-Worker wird im Native-Bundle entfernt.
- Store-Entitlements kommen ausschließlich aus dem serverseitig verifizierten `company_subscriptions`-Status.

## Bundle-/Package-ID
`com.harunxaa.angebotspilot`

## Store-Billing – harte Freigaberegeln

- Ein Store-Kauf wird nur vom Web-Layer angeboten, wenn der serverseitige Katalog `verification_ready=true` **und** den erwarteten Verifikationsmodus meldet.
- `autoAcknowledgePurchases=false`: iOS/Android werden erst nach erfolgreicher Server-Verifikation abgeschlossen/bestätigt.
- iOS `transactionUpdated` lädt bei Bedarf zuerst den aktuellen Katalog, verifiziert serverseitig und beendet die StoreKit-Transaktion erst danach.
- Die Transaktionsumgebung (`Sandbox`/`Production`) überschreibt beim Server-Verify die Build-Vorgabe, sofern StoreKit sie liefert.
- Android `com.android.vending.BILLING` wird durch `scripts/patch-android.mjs` nach `cap sync android` sichergestellt.
- Für einen späteren Sandbox-Build kann `AP_NATIVE_STORE_ENVIRONMENT=sandbox` gesetzt werden. Ohne Vorgabe bleibt `production`.
- Solange Apple-/Google-Serververifikation und echte Store-Produkte nicht aktiviert sind, bleiben Kauf und Restore gesperrt. Bestehende Stripe-Web-Abos behalten ihren Zugang.


## v0.3.6 Store & Chat Compliance
- iOS PrivacyInfo.xcprivacy wird als App-Resource eingebunden.
- Native Web Bundle verlangt chat-compliance.js.
- Chat UGC: Regeln, Melden, Blockieren, Moderation, Retention/Legal-Hold Backend vorbereitet.
- Store Privacy/Data Safety Checklist liegt in STORE_PRIVACY_CHECKLIST.md.
