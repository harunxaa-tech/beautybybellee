# AngebotsPilot Store Privacy Checklist – Native v0.5.0

Technischer Vorbereitungsstand für TestFlight / Google Play Internal Testing. Vor öffentlicher Veröffentlichung müssen die Angaben gegen den finalen Produktionsbuild und die finalen Anbieter/SDKs geprüft werden.

## Apple App Privacy / Privacy Manifest
- Tracking: **Nein** (keine Werbe-/Cross-App-Tracking-Logik vorgesehen).
- App-Funktionalität: Name, E-Mail, Telefonnummer, Anschrift, Zahlungs-/Bankangaben, Kontakte, E-Mail-/Textinhalte, Fotos/Videos, Audio/Sprachmemos, Supportdaten, sonstige Nutzerinhalte, User-ID.
- Standort: nur für vom Nutzer ausgelöste Wetter-/Standortfunktion; final prüfen, ob als präziser Standort an einen Dienst übertragen wird und entsprechend App Store Connect angeben.
- `PrivacyInfo.xcprivacy` muss im App-Target als Resource enthalten sein.
- Vor Upload in Xcode den **Privacy Report** erzeugen und Drittanbieter-Manifeste (Capacitor/Plugins) gegen den finalen Build prüfen.

## Google Play Data Safety
Finale Angaben müssen mindestens prüfen/abbilden:
- Account-/Kontaktdaten
- Kunden-/Betriebsdaten
- Chatnachrichten und Dateien
- Fotos/Videos und Audio/Sprachmemos
- Kontakte (nur Nutzerwahl)
- E-Mail-Inhalte bei verbundenem Postfach
- Standort/Wetterfunktion
- Support-/Sicherheitsmeldungen
- Geräte-/Push-Token für Benachrichtigungen (App-Funktionalität, nicht Tracking)
- Zahlungs-/Abo-Metadaten; Store-Zahlungsdaten selbst werden von Apple/Google verarbeitet
- Löschpfad in App und öffentliche `account-deletion.html`

## Baustellenchat / UGC
- Nutzungsregeln vor erstem Posten
- In-App-Melden und Blockieren
- Moderation Inhaber/Büro
- Baseline-Inhaltsfilter für schwere Drohungen
- Aufbewahrung standardmäßig 180 Tage nach abgeschlossener Baustelle; konfigurierbar
- Legal Hold nur für konkreten Rechts-/Sicherheitsfall
- Kontolöschung entfernt/anonymisiert Chat-UGC, soweit keine dokumentierte Ausnahme greift
- Push-Inhalte datensparsam; kein vertraulicher Nachrichtentext auf Sperrbildschirm

## Vor Store-Einreichung noch erforderlich
- Öffentliche Support-E-Mail/Support-URL des AngebotsPilot-Betreibers eintragen
- finale Datenschutzerklärung / AVV / Subprozessorliste / Impressum / Nutzungsbedingungen
- APNs/FCM Credentials serverseitig konfigurieren und Sandbox-/Internal-Tests durchführen
- finalen Xcode Privacy Report und Google Data Safety Fragebogen mit realem Releasebuild abgleichen

## Native Push
- Push-Berechtigung wird erst nach ausdrücklicher Nutzeraktion angefragt.
- Geräte-Token wird nur dem aktuell angemeldeten Benutzer/Betrieb zugeordnet und bei Accountwechsel serverseitig neu zugeordnet.
- Keine Werbeprofile/Tracking-Nutzung des Tokens.
- Benachrichtigungsinhalte auf dem Sperrbildschirm datensparsam halten.
- APNs/FCM-Produktivzustellung erst nach finalen Store-Credentials aktivieren und testen.

## Native Navigation / Deep Links
- Deep-Link-Grundlage `angebotspilot://` ist vorbereitet.
- Vor öffentlichem Release Universal Links/App Links auf die finale Produktdomain umstellen und Apple-AASA/Android-assetlinks verifizieren.
- Keine Auth-/Invite-Tokens in Analytics oder Push-Payloads protokollieren.
