import { readFile, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here = path.dirname(fileURLToPath(import.meta.url));
const nativeDir = path.resolve(here, '..');
const manifestPath = path.join(nativeDir, 'android', 'app', 'src', 'main', 'AndroidManifest.xml');
const billingPermission = '<uses-permission android:name="com.android.vending.BILLING" />';
const microphonePermission = '<uses-permission android:name="android.permission.RECORD_AUDIO" />';
const notificationPermission = '<uses-permission android:name="android.permission.POST_NOTIFICATIONS" />';


const deepLinkFilter = `
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="angebotspilot" />
            </intent-filter>
            <intent-filter>
                <action android:name="android.intent.action.VIEW" />
                <category android:name="android.intent.category.DEFAULT" />
                <category android:name="android.intent.category.BROWSABLE" />
                <data android:scheme="https" android:host="harunxaa-tech.github.io" android:pathPrefix="/beautybybellee" />
            </intent-filter>`;

function patchMainActivity(input){
  const re=/(<activity\b[^>]*android:name="\.MainActivity"[^>]*>)([\s\S]*?)(<\/activity>)/;
  const m=input.match(re);
  if(!m)throw new Error('Android MainActivity nicht gefunden.');
  let opening=m[1];
  if(/android:windowSoftInputMode="[^"]*"/.test(opening))opening=opening.replace(/android:windowSoftInputMode="[^"]*"/,'android:windowSoftInputMode="adjustResize"');
  else opening=opening.replace(/>$/, ' android:windowSoftInputMode="adjustResize">');
  if(/android:launchMode="[^"]*"/.test(opening))opening=opening.replace(/android:launchMode="[^"]*"/,'android:launchMode="singleTask"');
  else opening=opening.replace(/>$/, ' android:launchMode="singleTask">');
  let body=m[2];
  if(!body.includes('android:scheme="angebotspilot"'))body+=deepLinkFilter;
  return input.replace(re,opening+body+m[3]);
}

let manifest = await readFile(manifestPath, 'utf8');
if (!manifest.includes('android.permission.INTERNET')) {
  console.warn('AndroidManifest enthält keine erwartete INTERNET-Berechtigung; BILLING wird trotzdem ergänzt.');
}
if (!manifest.includes('com.android.vending.BILLING')) {
  manifest = manifest.replace(/(<manifest\b[^>]*>)/, `$1\n    ${billingPermission}`);
}
if (!manifest.includes('android.permission.RECORD_AUDIO')) {
  manifest = manifest.replace(/(<manifest\b[^>]*>)/, `$1\n    ${microphonePermission}`);
}
if (!manifest.includes('android.permission.POST_NOTIFICATIONS')) {
  manifest = manifest.replace(/(<manifest\b[^>]*>)/, `$1\n    ${notificationPermission}`);
}
manifest = patchMainActivity(manifest);
await writeFile(manifestPath, manifest, 'utf8');
if (!manifest.includes('com.android.vending.BILLING')) throw new Error('Google Play BILLING permission konnte nicht gesetzt werden.');
if (!manifest.includes('android.permission.RECORD_AUDIO')) throw new Error('Android RECORD_AUDIO permission konnte nicht gesetzt werden.');
if (!manifest.includes('android.permission.POST_NOTIFICATIONS')) throw new Error('Android POST_NOTIFICATIONS permission konnte nicht gesetzt werden.');
if (!manifest.includes('android:scheme="angebotspilot"')) throw new Error('Android Deep-Link-Scheme konnte nicht gesetzt werden.');
if (!manifest.includes('android:windowSoftInputMode="adjustResize"')) throw new Error('Android Keyboard adjustResize konnte nicht gesetzt werden.');
const gradlePath=path.join(nativeDir,'android','app','build.gradle');
let gradle=await readFile(gradlePath,'utf8');
const buildNumber=Math.max(1,Number(process.env.CM_BUILD_NUMBER)||1);
gradle=gradle.replace(/versionCode\s+\d+/g,`versionCode ${buildNumber}`).replace(/versionName\s+["'][^"']+["']/g,'versionName "0.5.0"');
await writeFile(gradlePath,gradle,'utf8');
console.log(`Android project patched: native v0.5.0 build ${buildNumber}, billing, microphone, push permission, keyboard resize + deep links present.`);
