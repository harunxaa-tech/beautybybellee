import { access, readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const nativeDir=path.resolve(here,'..');
const platform=String(process.env.AP_RELEASE_PLATFORM||'ios').toLowerCase();
const result={platform,native:'0.5.0',ready:true,missing:[],warnings:[]};
if(platform==='ios'){
  for(const key of ['APPLE_TEAM_ID'])if(!process.env[key])result.missing.push(key);
  if(!process.env.APP_STORE_CONNECT_KEY_IDENTIFIER)result.missing.push('APP_STORE_CONNECT_KEY_IDENTIFIER');
  if(!process.env.APP_STORE_CONNECT_ISSUER_ID)result.missing.push('APP_STORE_CONNECT_ISSUER_ID');
  if(!process.env.APP_STORE_CONNECT_PRIVATE_KEY)result.missing.push('APP_STORE_CONNECT_PRIVATE_KEY');
  result.warnings.push('APNs remote delivery also requires the App ID capability + valid signing profile.');
}else if(platform==='android'){
  try{await access(path.join(nativeDir,'google-services.json'))}catch{result.missing.push('native/google-services.json')}
  result.warnings.push('Google Play internal testing additionally needs Play Console signing/service-account setup.');
}else result.missing.push('AP_RELEASE_PLATFORM=ios|android');
result.ready=result.missing.length===0;
console.log(JSON.stringify(result,null,2));
if(!result.ready)process.exitCode=2;
