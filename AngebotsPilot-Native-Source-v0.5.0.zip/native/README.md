# AngebotsPilot Native iOS/Android v0.5.0


## Native Phase 2 – v0.5.0

- `@capacitor/push-notifications` als native APNs/FCM-Bridge ergänzt.
- Native Push-Berechtigung, Token-Registrierung und Action-Handling vorbereitet.
- Geräte-Tokens werden ausschließlich nach Login über die serverseitige RPC `register_native_push_device` dem aktiven Benutzer/Betrieb zugeordnet.
- Token-Reassignment verhindert, dass ein Gerät nach einem Accountwechsel Push für den vorherigen Nutzer erhält.
- Push-Taps routen interne AngebotsPilot-Ziele sowie sichere `angebotspilot://`-/Projekt-Deep-Links zurück in die App.
- Deep-Link-Parser akzeptiert Auth-/Recovery-Parameter aus Query **und** Fragment und verwirft unbekannte Parameter.
- iOS-Patch erzeugt `App.entitlements` mit `aps-environment`; Android ergänzt `POST_NOTIFICATIONS`.
- iOS/Android Marketing-Versionen werden auf 0.5.0 gesetzt; Buildnummer kommt in CI aus `CM_BUILD_NUMBER`.
- `release:preflight` prüft die noch fehlenden Store-/Signing-Voraussetzungen, bevor ein echter Geräte-/TestFlight-Build gestartet wird.

**Wichtig:** Die Registrierungsstrecke und das Backend-Geräteregister sind fertig. Echte Remote-Zustellung über APNs/FCM wird erst aktiviert, wenn Apple-/Firebase-Credentials und signierte App-Profile vorhanden sind.

Dieser Native-Build nutzt weiterhin die bestehende AngebotsPilot-Web-App als fachliche Codebasis und ergänzt native Gerätefunktionen sowie die vorbereitete Store-Billing-Bridge.

## Basis aus v0.4.0

- Globale Smart Search aus v11.32.8 ist Pflichtbestandteil des nativen Web-Bundles (`smart-search.js` + `smart-search.css`).
- Suche bleibt lokal/offline und erzeugt keine KI-Kosten.
- Mehrsprachige Benutzeroberfläche (DE/EN/PL/RO/HR/BS/SR/FR/IT/TR) mit benutzerspezifischer Cloud-Sprache.
- `i18n.js` ist Pflichtbestandteil des Native-Web-Bundles; Kundendaten sowie Rechnungs-/Rechtstexte werden nicht ungeprüft automatisch übersetzt.
- Mikrofon-Berechtigungen für Baustellenchat- und Angebots-Sprachmemos auf iOS/Android vorbereitet.
- Der Web-Bundle-Workflow übernimmt die gemeinsame Voice-Komponente; Aufnahme bleibt nutzergesteuert.
- KI-Transkription/Übersetzung bleibt serverseitig kosten-/consent-gated und enthält keinen API-Schlüssel im Native-Bundle.
- Voice-Pipeline: `gpt-transcribe` für Sprache→Text und serverseitig konfiguriertes `gpt-6-astra` für kontextbezogene Übersetzung/Angebotsvorschläge; aktuell deaktiviert, bis API-Kosten bewusst freigeschaltet werden.
- Native Store-Bridge auf der bestehenden v0.3.0-Basis weitergehärtet; kein Neuaufbau.
- Serverantwort wird vor Finish/Acknowledge zusätzlich auf Provider, Tarif, Status und Event-ID gebunden.
- Die echte Apple-App-Store-Server- und Google-Play-Developer-API-Verifikation ist serverseitig implementiert; Freischaltung bleibt bis zu echten Store-Credentials/Produkten gesperrt.
- `@capgo/native-purchases` 8.7.0 für StoreKit 2 / Google Play Billing.
- Native Storepreise werden aus dem jeweiligen Store geladen; kein freigeschalteter Kauf verlässt sich auf hart codierte Storepreise.
- Kaufbelege werden an `store-billing-verify` gesendet. Die App selbst vergibt niemals ein Abo-Recht.
- Direkte Käufe laufen mit `autoAcknowledgePurchases:false`; Bestätigung erfolgt erst nach erfolgreicher Serverprüfung.
- Restore-Pfad prüft aktuelle Entitlements erneut serverseitig.
- iOS-Transaction-Updates werden an die Serverprüfung weitergereicht.
- Android-Unterbau und Capacitor-Android-Abhängigkeit ergänzt.

## Sicherheitszustand vor den Store-Konten
Apple- und Google-Käufe bleiben absichtlich gesperrt, solange der serverseitige Provider-Gate nicht aktiviert wurde. Produkt-IDs alleine reichen nicht aus. Dadurch kann vor Einrichtung der echten Store-Credentials kein versehentlicher Kauf freigeschaltet werden.

## Bestehende Native-Funktionen
- Face ID / Touch ID bzw. Gerätebiometrie für die App-Sperre.
- Kamera direkt in der Kundenakte.
- Dokumentaufnahme mit Zuschneiden als einfacher Scan-Workflow.
- Nativer Kontakt-Picker.
- Native Datei-/Share-Funktion für Backups und Bilder.
- Haptisches Erfolgsfeedback.

## Bewusst noch nicht live
- Finale Apple-Credentials / Root-Zertifikate im Server-Secret-Store.
- Finaler Google-Play-Service-Account im Server-Secret-Store.
- Echte Apple-/Google-Produkt-IDs.
- Signierte TestFlight-/Play-Internal-Test-Builds.
- Remote-Push über APNs/FCM.

## Architektur
- Root-Dateien des Repositories bleiben die Web-Quelle.
- `prepare:web` kopiert sie nach `native/www`.
- `injected/native-features.js` enthält Gerätefunktionen.
- `injected/native-store-billing.js` enthält nur den Native-Store-Adapter; die zentrale Abo-Logik bleibt in `store-billing.js`.
- Der PWA-Service-Worker wird im Native-Bundle entfernt.
- Store-Entitlements kommen ausschließlich aus dem serverseitig verifizierten `company_subscriptions`-Status.

## Bundle-/Package-ID
`com.harunxaa.angebotspilot`

## Store-Billing – harte Freigaberegeln

- Ein Store-Kauf wird nur vom Web-Layer angeboten, wenn der serverseitige Katalog `verification_ready=true` **und** den erwarteten Verifikationsmodus meldet.
- `autoAcknowledgePurchases=false`: iOS/Android werden erst nach erfolgreicher Server-Verifikation abgeschlossen/bestätigt.
- iOS `transactionUpdated` lädt bei Bedarf zuerst den aktuellen Katalog, verifiziert serverseitig und beendet die StoreKit-Transaktion erst danach.
- Die Transaktionsumgebung (`Sandbox`/`Production`) überschreibt beim Server-Verify die Build-Vorgabe, sofern StoreKit sie liefert.
- Android `com.android.vending.BILLING` wird durch `scripts/patch-android.mjs` nach `cap sync android` sichergestellt.
- Für einen späteren Sandbox-Build kann `AP_NATIVE_STORE_ENVIRONMENT=sandbox` gesetzt werden. Ohne Vorgabe bleibt `production`.
- Solange Apple-/Google-Serververifikation und echte Store-Produkte nicht aktiviert sind, bleiben Kauf und Restore gesperrt. Bestehende Stripe-Web-Abos behalten ihren Zugang.


## v0.4.0 Store & Chat Compliance
- iOS PrivacyInfo.xcprivacy wird als App-Resource eingebunden.
- Native Web Bundle verlangt chat-compliance.js.
- Chat UGC: Regeln, Melden, Blockieren, Moderation, Retention/Legal-Hold Backend vorbereitet.
- Store Privacy/Data Safety Checklist liegt in STORE_PRIVACY_CHECKLIST.md.

## Native Phase 1 – v0.4.0

- Native Lifecycle-Bridge für Vordergrund/Hintergrund; beim Zurückkehren wird die App-Sperre erneut geprüft.
- iOS/Android Deep-Link-Grundlage mit `angebotspilot://` für Einladungen und spätere App-Links.
- Android akzeptiert zusätzlich die aktuelle GitHub-Pages-Webadresse als Deep Link; die finale Produktdomain wird vor Store-Release separat verifiziert.
- Android-Zurück-Taste schließt zuerst offene Sheets/Modals, navigiert danach zur Startseite und minimiert die App erst dort.
- Native Keyboard-Lifecycle mit `adjustResize` auf Android und eigener `native-keyboard-open`-UI-Klasse.
- Safe-Area-/Dynamic-Viewport-Härtung für iPhone/Android sowie Bottom-Navigation und Native-Sheets.
- Externe HTTPS-Links werden in der nativen Browser-Ansicht geöffnet statt die AngebotsPilot-WebView zu verlassen.
- Native Build-Marker `__AP_NATIVE_BUILD__ = "0.4.0"` und `BUILD_INFO.json`.
- Neuer `native-doctor` prüft vor jedem Build Version, App-ID, Pflichtplugins, Deep-Link-Patches, Privacy-Manifest und offensichtliche Secret-Leaks.
- PWA-Service-Worker und Manifest bleiben im Native-Webbundle weiterhin deaktiviert.

### Noch bewusst nicht Bestandteil von Phase 1

- APNs/FCM Remote-Push und echte Store-Signierung.
- Universal Links / App Links mit finaler AngebotsPilot-Domain und verifizierter Association-Datei.
- App-Store-/Play-Store-Produktivprodukte und Credentials.
- Release-Signing/TestFlight/Play-Internal-Testing.
