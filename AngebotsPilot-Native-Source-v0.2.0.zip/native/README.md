# AngebotsPilot Native iOS v0.2.0

Dieser Native-Build nutzt weiterhin die bestehende AngebotsPilot-Web-App als einzige fachliche Codebasis und ergänzt nur iPhone-Funktionen.

## Neu in v0.2.0
- Face ID / Touch ID für die bestehende automatische App-Sperre.
- iPhone-Kamera direkt in der Kundenakte.
- Dokumentaufnahme mit iOS-Zuschneiden als einfacher Scan-Workflow.
- Nativer Kontakt-Picker für den bestehenden Bestandskunden-Import.
- Native Datei-/Share-Funktion für AngebotsPilot-Backups und aufgenommene Bilder.
- Haptisches Erfolgsfeedback.

## Bewusst noch nicht aktiviert
Remote-Push über APNs. Dafür benötigen wir später Apple-Signierung/Entitlements und eine Erweiterung der Push-Token-Speicherung im Backend. In-App-Benachrichtigungen bleiben aktiv.

## Architektur
- Root-Dateien des Repositories bleiben die Web-Quelle.
- `prepare:web` kopiert sie nach `native/www`.
- Native-only UI liegt in `injected/native-features.js`.
- Der PWA-Service-Worker wird nur im Native-Bundle entfernt.
- `prepare:web` ergänzt nur im Native-Bundle einen sicheren Unlock-Hook für die bestehende SecurityCenter-Logik.
- `patch-ios` ergänzt iOS-Datenschutztexte, App-Icon/Splash und die Native-Version.

## Bundle-ID
`com.harunxaa.angebotspilot`
