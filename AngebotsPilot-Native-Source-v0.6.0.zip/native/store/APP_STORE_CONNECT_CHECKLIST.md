# AngebotsPilot – App Store Connect / TestFlight Readiness (Native v0.6.0)

## Technisch bereits vorbereitet
- Bundle ID: `com.harunxaa.angebotspilot`
- App-Name: AngebotsPilot
- iPhone-only Target
- Native Version: 0.6.0
- Web Release: 11.32.20
- App Icon 1024×1024 ohne Transparenz
- Splash Asset 2732×2732
- PrivacyInfo.xcprivacy eingebunden
- Deep Link `angebotspilot://`
- Push-Entitlement `aps-environment`
- Kamera, Fotos, Kontakte, Mikrofon und Face-ID Usage Descriptions
- Native Push-Token-Registrierung im Backend
- PKCE-/Recovery-Callback-Härtung
- Codemagic unsigned Simulator-Smoke-Build
- Codemagic TestFlight-Workflow vorbereitet

## Erst mit Apple Developer Program möglich
1. Apple Developer Program aktivieren.
2. App-ID / Bundle-ID `com.harunxaa.angebotspilot` im Apple Developer Portal verwenden.
3. App Store Connect App-Eintrag „AngebotsPilot“ anlegen.
4. App Store Connect API Key und Apple Distribution Signing in Codemagic hinterlegen.
5. Push Notifications Capability/Provisioning aktivieren.
6. TestFlight-Workflow `angebotspilot-ios-testflight` starten.

## Vor öffentlichem Store-Release noch final entscheiden
- Öffentliche Datenschutz-URL
- Support-URL
- Anbieter-/Copyright-Angabe
- App Store Kategorie / Untertitel / Beschreibung
- App Privacy Antworten anhand der tatsächlich live geschalteten Funktionen
- Screenshots auf echten iPhone-Größen
- Store-Billing-Produkte und Apple-/Google-Server-Credentials
- Juristische Schlussprüfung der veröffentlichten Anbieter-/AGB-/Datenschutztexte

## Sicherheitsregel
Keine `.p8`, `.p12`, Zertifikate, privaten Schlüssel oder Service-Role-Keys in GitHub oder in die Native-ZIP legen. Secrets gehören ausschließlich in geschützte Codemagic-/Server-Secret-Stores.
