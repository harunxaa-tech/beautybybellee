import { access, readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
const here=path.dirname(fileURLToPath(import.meta.url));
const nativeDir=path.resolve(here,'..');
const platform=String(process.env.AP_RELEASE_PLATFORM||'ios').toLowerCase();
const requireSigning=String(process.env.AP_REQUIRE_SIGNING||'0')==='1';
const result={platform,native:'0.6.0',web:'11.32.20',ready:true,missing:[],warnings:[],checks:[]};
const need=(key)=>{if(!process.env[key])result.missing.push(key);else result.checks.push(`${key}: vorhanden`)};

if(platform==='ios'){
  for(const rel of ['assets/AppIcon-1024.png','assets/Splash-2732.png','privacy/PrivacyInfo.xcprivacy','store/APP_STORE_CONNECT_CHECKLIST.md']){
    try{await access(path.join(nativeDir,rel));result.checks.push(`${rel}: vorhanden`)}catch{result.missing.push(`native/${rel}`)}
  }
  if(requireSigning){
    need('APP_STORE_CONNECT_KEY_IDENTIFIER');
    need('APP_STORE_CONNECT_ISSUER_ID');
    need('APP_STORE_CONNECT_PRIVATE_KEY');
    need('CERTIFICATE_PRIVATE_KEY');
  }else{
    result.warnings.push('Signing-Credentials werden erst für den TestFlight-Workflow benötigt.');
  }
  result.warnings.push('Vor dem ersten Upload muss in App Store Connect ein App-Eintrag für com.harunxaa.angebotspilot existieren.');
  result.warnings.push('APNs-Produktion benötigt eine gültige Apple-Signing-/Push-Konfiguration.');
}else if(platform==='android'){
  try{await access(path.join(nativeDir,'google-services.json'));result.checks.push('google-services.json: vorhanden')}catch{result.warnings.push('native/google-services.json fehlt noch; FCM-Remote-Push bleibt bis dahin aus.')}
  result.warnings.push('Google Play Internal Testing benötigt später Play Console Signing/Service-Account.');
}else result.missing.push('AP_RELEASE_PLATFORM=ios|android');
result.ready=result.missing.length===0;
console.log(JSON.stringify(result,null,2));
if(!result.ready)process.exitCode=2;
