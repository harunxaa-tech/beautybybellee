import { access, readFile } from 'node:fs/promises';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

const here=path.dirname(fileURLToPath(import.meta.url));
const nativeDir=path.resolve(here,'..');
const read=rel=>readFile(path.join(nativeDir,rel),'utf8');
const bytes=rel=>readFile(path.join(nativeDir,rel));
const fail=msg=>{throw new Error(`Native doctor: ${msg}`)};

function pngInfo(buf){
  if(buf.length<29||buf.toString('ascii',1,4)!=='PNG')fail('ungültige PNG-Datei');
  const width=buf.readUInt32BE(16),height=buf.readUInt32BE(20),bitDepth=buf[24],colorType=buf[25];
  return {width,height,bitDepth,colorType,hasAlpha:colorType===4||colorType===6};
}

const pkg=JSON.parse(await read('package.json'));
const config=JSON.parse(await read('capacitor.config.json'));
const buildInfo=JSON.parse(await read('BUILD_INFO.json'));
if(pkg.version!=='0.6.0')fail(`package version ${pkg.version} != 0.6.0`);
if(buildInfo.native_version!=='0.6.0'||buildInfo.web_release!=='11.32.20')fail('BUILD_INFO-Versionen stimmen nicht');
if(config.appId!=='com.harunxaa.angebotspilot')fail(`unerwartete appId ${config.appId}`);
if(config.webDir!=='www')fail('webDir muss www sein');
const deps=['@capacitor/app','@capacitor/browser','@capacitor/camera','@capacitor/filesystem','@capacitor/haptics','@capacitor/keyboard','@capacitor/share','@capacitor/splash-screen','@capacitor/status-bar','@capacitor/push-notifications','@capacitor-community/contacts','@aparajita/capacitor-biometric-auth','@capgo/native-purchases'];
for(const dep of deps)if(!pkg.dependencies?.[dep])fail(`Dependency fehlt: ${dep}`);
for(const rel of ['assets/AppIcon-1024.png','assets/Splash-2732.png','privacy/PrivacyInfo.xcprivacy','injected/native-features.js','injected/native-store-billing.js','store/APP_STORE_CONNECT_CHECKLIST.md','store/APP_STORE_METADATA_TEMPLATE.json'])await access(path.join(nativeDir,rel));

const icon=pngInfo(await bytes('assets/AppIcon-1024.png'));
if(icon.width!==1024||icon.height!==1024)fail(`AppIcon muss 1024x1024 sein, ist ${icon.width}x${icon.height}`);
if(icon.hasAlpha)fail('AppIcon darf für App Store Connect keinen Alpha-Kanal enthalten');
const splash=pngInfo(await bytes('assets/Splash-2732.png'));
if(splash.width!==2732||splash.height!==2732)fail(`Splash muss 2732x2732 sein, ist ${splash.width}x${splash.height}`);

const features=await read('injected/native-features.js');
for(const marker of ["NATIVE_BUILD='0.6.0'",'appUrlOpen','keyboardWillShow','backButton','openDeepLink','Browser','PushNotifications','register_native_push_device','pushNotificationActionPerformed'])if(!features.includes(marker))fail(`Runtime-Marker fehlt: ${marker}`);
const ios=await read('scripts/patch-ios.mjs');
if(!ios.includes('angebotspilot'))fail('iOS Deep-Link-Patch fehlt');
if(!ios.includes('MARKETING_VERSION = 0.6.0'))fail('iOS Marketing-Version ist nicht 0.6.0');
if(!ios.includes('aps-environment'))fail('iOS Push-Entitlement-Patch fehlt');
if(!ios.includes('APPLE_TEAM_ID')||!ios.includes('CODE_SIGN_STYLE = Automatic'))fail('iOS Signing-Hook fehlt');
const android=await read('scripts/patch-android.mjs');
for(const marker of ['android:scheme="angebotspilot"','adjustResize','singleTask','android.permission.POST_NOTIFICATIONS','versionName "0.6.0"'])if(!android.includes(marker))fail(`Android Patch-Marker fehlt: ${marker}`);
const prepare=await read('scripts/prepare-web.mjs');
if(!prepare.includes('ap_native_callback'))fail('Native Auth callback bridge fehlt');
if(!prepare.includes("flowType:'pkce'"))fail('Native PKCE-Patch fehlt');
if(!prepare.includes('__AP_NATIVE_BUILD__="0.6.0"'))fail('prepare:web Build-Marker fehlt');
if(/(?:sk-[A-Za-z0-9_-]{20,}|service_role\s*[:=]\s*["'][^"']+)/i.test(features+await read('injected/native-store-billing.js')))fail('potenzielles Secret im Native-Bundle gefunden');
console.log(`Native doctor OK: v0.6.0 · web 11.32.20 · icon ${icon.width}x${icon.height} ohne Alpha · iOS/Android · TestFlight readiness.`);
